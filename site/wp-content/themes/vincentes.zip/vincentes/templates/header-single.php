<?php
/**
 * The template to display the featured image in the single post
 *
 * @package WordPress
 * @subpackage VINCENTES
 * @since VINCENTES 1.0
 */


?>